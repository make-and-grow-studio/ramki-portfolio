// Kovai Valley diorama — Make & Grow edition
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

const RR = window.RR, hero = document.getElementById('top'), host = document.getElementById('stage3d'), canvas = document.getElementById('sky');
const small = Math.min(innerWidth, innerHeight) < 700, reduce = RR.reduce;

/* ================= renderer / scene ================= */
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
renderer.setClearColor(0x000000, 0);
renderer.setPixelRatio(Math.min(devicePixelRatio || 1, small ? 1.5 : 2));
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
const scene = new THREE.Scene();
const pmrem = new THREE.PMREMGenerator(renderer);
scene.environment = pmrem.fromScene(new RoomEnvironment(renderer), .04).texture;
const camera = new THREE.PerspectiveCamera(34, 1, 1, 2000);
const TARGET = new THREE.Vector3(0, 9, -4);
const world = new THREE.Group(); scene.add(world);

/* ================= helpers ================= */
const col = h => new THREE.Color(h);
const C255 = a => new THREE.Color().setRGB(a[0] / 255, a[1] / 255, a[2] / 255, THREE.SRGBColorSpace);
const smooth = (e0, e1, x) => { const t = Math.min(1, Math.max(0, (x - e0) / (e1 - e0))); return t * t * (3 - 2 * t); };
const lerp = (a, b, k) => a + (b - a) * k;
const hash = (x, y) => { const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453; return s - Math.floor(s); };
function vnoise(x, y) { const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi, u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf); const a = hash(xi, yi), b = hash(xi + 1, yi), c = hash(xi, yi + 1), d = hash(xi + 1, yi + 1); return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v; }
function fbm(x, y, o = 5) { let s = 0, a = .5, f = 1; for (let i = 0; i < o; i++) { s += a * vnoise(x * f, y * f); f *= 2.02; a *= .5; } return s; }
const g2 = (x, z, cx, cz, s) => Math.exp(-((x - cx) ** 2 + (z - cz) ** 2) / (2 * s * s));
let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
const M4 = new THREE.Matrix4(), Q = new THREE.Quaternion(), V = new THREE.Vector3(), SV = new THREE.Vector3(), E = new THREE.Euler();
const mat = (o) => new THREE.MeshStandardMaterial(o);
const envMats = [];
function M(o) { const m = mat(o); envMats.push(m); return m; }
const pickables = [];
const pickable = (obj, id, anchor) => { obj.userData.pick = id; obj.userData.anchor = anchor || new THREE.Vector3(); pickables.push(obj); return obj; };
function softTex(size = 128, stops = [[0, 1], [.35, .5], [1, 0]]) {
  const c = document.createElement('canvas'); c.width = c.height = size; const x = c.getContext('2d');
  const g = x.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  stops.forEach(([o, a]) => g.addColorStop(o, `rgba(255,255,255,${a})`)); x.fillStyle = g; x.fillRect(0, 0, size, size);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
const GLOW = softTex(128, [[0, 1], [.2, .55], [.5, .12], [1, 0]]);
const PUFF = (() => {
  const s = 128, c = document.createElement('canvas'); c.width = c.height = s; const x = c.getContext('2d');
  for (let i = 0; i < 14; i++) { const r = 18 + Math.random() * 26, px = 64 + (Math.random() - .5) * 46, py = 64 + (Math.random() - .5) * 40; const g = x.createRadialGradient(px, py, 0, px, py, r); g.addColorStop(0, 'rgba(255,255,255,.55)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, s, s); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
})();
const glowSprite = (color, size, opacity = 0) => { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: GLOW, color, transparent: true, opacity, blending: THREE.AdditiveBlending, depthWrite: false })); s.scale.setScalar(size); return s; };

/* ================= terrain height ================= */
const R = 60, BAND = .6;
const LAKE = { x: 6, z: 15 }, TEMPLE = { x: -30, z: -4 }, TEA = { x: 23, z: 2 }, PLAZA = { x: 31, z: 27 }, VILLAGE = { x: -17, z: 26 };
function rawH(x, z) {
  let h = .9 + 1.5 * fbm(x * .05 + 3, z * .05 + 7, 4);
  const back = smooth(-4, -32, z);
  const rid = 1 - Math.abs(vnoise(x * .085 + 11, z * .085 + 5) * 2 - 1);
  h += back * (5 + 15 * fbm(x * .045 + 1, z * .045 + 2, 5) + 7 * rid * rid);
  h += 21 * g2(x, z, 4, -32, 9.5) + 15 * g2(x, z, -21, -27, 8) + 13 * g2(x, z, 22, -28, 8.5);
  h += 8.5 * g2(x, z, TEMPLE.x, TEMPLE.z, 11);
  h += 6.5 * g2(x, z, TEA.x, TEA.z, 7);
  h -= 3.6 * smooth(13, 4, Math.hypot(x - LAKE.x, z - LAKE.z));
  return h;
}
const PLATEAU = rawH(TEMPLE.x, TEMPLE.z) - .3;
function H(x, z) {
  let h = rawH(x, z);
  const dt = Math.hypot(x - TEA.x, z - TEA.z), mt = smooth(12, 8, dt);
  if (mt > 0) { const s = 1.05, t = h / s, f = t - Math.floor(t); h = lerp(h, (Math.floor(t) + smooth(.3, .7, f)) * s, mt); }
  h = lerp(h, PLATEAU, smooth(13, 7.2, Math.hypot(x - TEMPLE.x, z - TEMPLE.z)));
  h = lerp(h, 1.0, smooth(12, 9.4, Math.hypot(x - PLAZA.x, z - PLAZA.z)));
  h = lerp(h, 1.15 + .25 * Math.sin(x * .3), smooth(11, 7, Math.hypot(x - VILLAGE.x, z - VILLAGE.z)));
  h = lerp(h, BAND, smooth(43, 48.5, Math.hypot(x, z)));
  return h;
}

/* ================= terrain mesh (polar grid, contour shader) ================= */
function polar(Rad, rings, segs, fn) {
  const pos = [0, fn(0, 0), 0], idx = [];
  for (let i = 1; i <= rings; i++) { const r = Rad * i / rings; for (let j = 0; j < segs; j++) { const a = j / segs * Math.PI * 2, x = Math.cos(a) * r, z = Math.sin(a) * r; pos.push(x, fn(x, z), z); } }
  for (let j = 0; j < segs; j++) idx.push(0, 1 + (j + 1) % segs, 1 + j);
  for (let i = 1; i < rings; i++) { const a0 = 1 + (i - 1) * segs, a1 = 1 + i * segs; for (let j = 0; j < segs; j++) { const j1 = (j + 1) % segs; idx.push(a0 + j, a0 + j1, a1 + j, a0 + j1, a1 + j1, a1 + j); } }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setIndex(idx); g.computeVertexNormals(); return g;
}
const terrGeo = polar(R, small ? 90 : 120, small ? 220 : 320, H);
{
  const p = terrGeo.attributes.position, n = terrGeo.attributes.normal, cols = [];
  const grass = col(0x8fae5a), forest = col(0x4e7d3e), rock = col(0x6f7d58), peak = col(0x8f9775), sand = col(0xd8c49a), pave = col(0xd3cab8), dirt = col(0xb79e74), band = col(0x9fae79), tea = col(0x5f9447), c = new THREE.Color();
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i), ny = n.getY(i), r = Math.hypot(x, z);
    c.copy(grass).lerp(forest, smooth(2.5, 9, y)).lerp(rock, smooth(16, 26, y)).lerp(peak, smooth(28, 38, y));
    c.lerp(rock, smooth(.8, .55, ny) * smooth(6, 12, y) * .7);
    c.lerp(tea, smooth(12, 8, Math.hypot(x - TEA.x, z - TEA.z)) * .8);
    c.lerp(sand, smooth(12.5, 9.5, Math.hypot(x - LAKE.x, z - LAKE.z)) * smooth(2.2, .6, y));
    c.lerp(pave, smooth(8.5, 6.5, Math.hypot(x - PLAZA.x, z - PLAZA.z)));
    c.lerp(dirt, smooth(10, 6, Math.hypot(x - VILLAGE.x, z - VILLAGE.z)) * .45);
    c.lerp(pave, smooth(6.5, 4.8, Math.hypot(x - TEMPLE.x, z - TEMPLE.z)) * .8);
    c.lerp(band, smooth(45, 49, r));
    const v = (hash(x * 3.1, z * 2.7) - .5) * .05; cols.push(c.r + v, c.g + v, c.b + v * .5);
  }
  terrGeo.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3));
}
const contourU = { uLine: { value: col(0x3d4f57) }, uLineAmt: { value: .22 } };
const terrMat = M({ vertexColors: true, roughness: .93, metalness: 0 });
terrMat.onBeforeCompile = sh => {
  Object.assign(sh.uniforms, contourU);
  sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying float vH;').replace('#include <begin_vertex>', '#include <begin_vertex>\nvH = position.y;');
  sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying float vH; uniform vec3 uLine; uniform float uLineAmt;')
    .replace('#include <dithering_fragment>', `#include <dithering_fragment>
      float hh = vH / 1.6; float w = fwidth(hh); float l = 1.0 - smoothstep(0.0, w * 1.2, abs(fract(hh - .5) - .5));
      float major = 1.0 - smoothstep(0.0, w * 1.6, abs(fract(hh / 5.0 - .5) - .5) * 5.0);
      gl_FragColor.rgb = mix(gl_FragColor.rgb, uLine, clamp(l * uLineAmt + major * uLineAmt * .9, 0.0, .6) * step(1.2, vH));`);
};
const terrain = new THREE.Mesh(terrGeo, terrMat); terrain.receiveShadow = true; terrain.castShadow = true; world.add(terrain);
pickable(terrain, 'land');

/* cut-away base with soil strata + plinth */
{
  const sk = new THREE.CylinderGeometry(R, R, 9.2, 256, 12, true); sk.translate(0, BAND - 4.6, 0);
  const p = sk.attributes.position, cols = [], c = new THREE.Color();
  const layers = [col(0x5f8f43), col(0x7a5c3f), col(0x9b7b56), col(0x6e5640), col(0xb4966b), col(0x5b4735), col(0x8c7052)];
  for (let i = 0; i < p.count; i++) { const y = p.getY(i); const d = BAND - y; const k = d < .35 ? 0 : Math.min(layers.length - 1, 1 + Math.floor((d - .35) / 1.45)); c.copy(layers[k]); cols.push(c.r, c.g, c.b); }
  sk.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3));
  const skirt = new THREE.Mesh(sk, M({ vertexColors: true, roughness: 1, flatShading: true })); skirt.castShadow = true; world.add(skirt);
  // plinth with engraved title
  const tc = document.createElement('canvas'); tc.width = 4096; tc.height = 64; const x = tc.getContext('2d');
  x.fillStyle = '#1c1f21'; x.fillRect(0, 0, 4096, 64); x.fillStyle = '#e4551c'; x.fillRect(0, 0, 4096, 3);
  x.font = '500 26px "JetBrains Mono", monospace'; x.fillStyle = '#cfcabd'; x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText('FIG. 01 — KOVAI VALLEY · 11.0168° N  76.9558° E · SCALE 1:5000 · DRAWN: RAMKI', 2048, 34);
  const tt = new THREE.CanvasTexture(tc); tt.colorSpace = THREE.SRGBColorSpace; tt.anisotropy = 8;
  const plinth = new THREE.Mesh(new THREE.CylinderGeometry(R + 1.6, R + 1.9, 1.8, 192, 1, false, -Math.PI, Math.PI * 2), [M({ map: tt, roughness: .6, metalness: .3 }), M({ color: 0x1c1f21, roughness: .55, metalness: .3 }), M({ color: 0x1c1f21 })]);
  plinth.position.y = BAND - 9.2 - .9; plinth.castShadow = plinth.receiveShadow = true; world.add(plinth);
  const lip = new THREE.Mesh(new THREE.TorusGeometry(R + .7, .14, 6, 256), M({ color: 0xe4551c, roughness: .4, emissive: 0xe4551c, emissiveIntensity: .15 }));
  lip.rotation.x = Math.PI / 2; lip.position.y = BAND - 9.2 + .02; world.add(lip);
}
// shadow catcher on the paper
const catcher = new THREE.Mesh(new THREE.PlaneGeometry(500, 500), new THREE.ShadowMaterial({ opacity: .18 }));
catcher.rotation.x = -Math.PI / 2; catcher.position.y = BAND - 11.1; catcher.receiveShadow = true; scene.add(catcher);
const ao = new THREE.Mesh(new THREE.PlaneGeometry(170, 170), new THREE.MeshBasicMaterial({ map: softTex(256, [[0, .55], [.55, .35], [1, 0]]), color: 0x191b1c, transparent: true, depthWrite: false }));
ao.rotation.x = -Math.PI / 2; ao.position.y = BAND - 11.05; scene.add(ao);

/* ================= lake ================= */
const waterNormal = (() => {
  const s = 128, c = document.createElement('canvas'); c.width = c.height = s; const x = c.getContext('2d'), img = x.createImageData(s, s);
  const hgt = (i, j) => fbm(i / 14, j / 14, 3) * 3;
  for (let j = 0; j < s; j++) for (let i = 0; i < s; i++) { const dx = hgt(i + 1, j) - hgt(i - 1, j), dy = hgt(i, j + 1) - hgt(i, j - 1); const k = (j * s + i) * 4; img.data[k] = 128 - dx * 60; img.data[k + 1] = 128 - dy * 60; img.data[k + 2] = 255; img.data[k + 3] = 255; }
  x.putImageData(img, 0, 0); const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(5, 5); return t;
})();
const waterMat = new THREE.MeshPhysicalMaterial({ color: 0x3f8f8c, roughness: .06, metalness: .05, normalMap: waterNormal, normalScale: new THREE.Vector2(.35, .35), transparent: true, opacity: .9, clearcoat: 1, clearcoatRoughness: .1 });
envMats.push(waterMat);
const water = new THREE.Mesh(new THREE.CircleGeometry(12.5, 64), waterMat); water.rotation.x = -Math.PI / 2; water.position.set(LAKE.x, .42, LAKE.z); water.receiveShadow = true; world.add(water);
pickable(water, 'lake', new THREE.Vector3(0, 0, 0));
// coracle
const coracle = new THREE.Group();
{ const b = new THREE.Mesh(new THREE.SphereGeometry(.95, 18, 8, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), M({ color: 0x6b4d2e, roughness: .9, side: THREE.DoubleSide })); b.castShadow = true; coracle.add(b);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(.95, .07, 6, 24), M({ color: 0x4f3820 })); rim.rotation.x = Math.PI / 2; coracle.add(rim);
  const man = new THREE.Mesh(new THREE.CapsuleGeometry(.18, .45, 4, 8), M({ color: 0xe9dcc4 })); man.position.y = .35; coracle.add(man);
  const head = new THREE.Mesh(new THREE.SphereGeometry(.15, 10, 8), M({ color: 0x5a3b28 })); head.position.y = .8; coracle.add(head);
  const oar = new THREE.Mesh(new THREE.CylinderGeometry(.03, .03, 1.8, 5), M({ color: 0x8a6a46 })); oar.rotation.z = .9; oar.position.set(.5, .5, 0); coracle.add(oar);
}
world.add(coracle);
const ripples = [];
function ripple(x, z) {
  for (let k = 0; k < 3; k++) {
    const m = new THREE.Mesh(new THREE.RingGeometry(.9, 1, 48), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: .7, depthWrite: false }));
    m.rotation.x = -Math.PI / 2; m.position.set(x, .46, z); world.add(m); ripples.push({ m, t: -k * .35 });
  }
}

/* ================= railway (loop) ================= */
const TR_R = 53.5, railY = BAND + .28;
{
  const ballast = new THREE.Mesh(new THREE.RingGeometry(TR_R - 1.7, TR_R + 1.7, 256, 1), M({ color: 0x9a8f7e, roughness: 1 }));
  ballast.rotation.x = -Math.PI / 2; ballast.position.y = BAND + .05; ballast.receiveShadow = true; world.add(ballast);
  const steel = M({ color: 0x5c5f63, roughness: .3, metalness: .9 });
  [-.72, .72].forEach(o => { const r = new THREE.Mesh(new THREE.TorusGeometry(TR_R + o, .09, 6, 360), steel); r.rotation.x = Math.PI / 2; r.position.y = railY; world.add(r); });
  const N = 300, sleep = new THREE.InstancedMesh(new THREE.BoxGeometry(.38, .14, 2.3), M({ color: 0x5b4a3a, roughness: 1 }), N);
  for (let i = 0; i < N; i++) { const a = i / N * Math.PI * 2; V.set(Math.cos(a) * TR_R, railY - .14, Math.sin(a) * TR_R); Q.setFromEuler(E.set(0, Math.PI / 2 - a, 0)); M4.compose(V, Q, SV.set(1, 1, 1)); sleep.setMatrixAt(i, M4); }
  sleep.receiveShadow = true; world.add(sleep);
  // station on the front
  const st = new THREE.Group(); const a = Math.PI / 2 + .18; st.position.set(Math.cos(a) * (TR_R + 3.6), BAND, Math.sin(a) * (TR_R + 3.6)); st.rotation.y = -a + Math.PI / 2;
  const plat = new THREE.Mesh(new THREE.BoxGeometry(14, .7, 2.6), M({ color: 0xd9d1c0, roughness: .9 })); plat.position.y = .35; st.add(plat);
  const bld = new THREE.Mesh(new THREE.BoxGeometry(5, 2.4, 2), M({ color: 0xf0e7d3 })); bld.position.set(0, 1.9, .2); st.add(bld);
  const roof = new THREE.Mesh(new THREE.BoxGeometry(9, .22, 3.2), M({ color: 0xe4551c, roughness: .6 })); roof.position.set(0, 3.25, -.1); roof.rotation.x = -.08; st.add(roof);
  [-4, -1.4, 1.4, 4].forEach(px => { const pst = new THREE.Mesh(new THREE.CylinderGeometry(.07, .07, 2.6, 6), M({ color: 0x1c1f21 })); pst.position.set(px, 2, -1.4); st.add(pst); });
  const sc = document.createElement('canvas'); sc.width = 512; sc.height = 96; const sx = sc.getContext('2d'); sx.fillStyle = '#f3f0e9'; sx.fillRect(0, 0, 512, 96); sx.fillStyle = '#191b1c'; sx.font = '700 44px Archivo, sans-serif'; sx.textAlign = 'center'; sx.textBaseline = 'middle'; sx.fillText('COIMBATORE JN.', 256, 50);
  const stt = new THREE.CanvasTexture(sc); stt.colorSpace = THREE.SRGBColorSpace;
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(3.6, .68), new THREE.MeshStandardMaterial({ map: stt })); sign.position.set(0, 2.2, 1.23); st.add(sign);
  st.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  world.add(st);
}
const winLit = M({ color: 0x24313a, emissive: 0xffc977, emissiveIntensity: 0, roughness: .25 });
const blue = M({ color: 0x2f62a8, roughness: .4, metalness: .15 }), cream = M({ color: 0xf0e4c6, roughness: .5 });
const iron = M({ color: 0x24282c, roughness: .45, metalness: .6 }), redP = M({ color: 0xa52f22, roughness: .45 }), brass = M({ color: 0xc89b3c, roughness: .3, metalness: .9 });
const train = new THREE.Group(), cars = [];
function car(engine) {
  const g = new THREE.Group();
  if (engine) {
    const boiler = new THREE.Mesh(new THREE.CylinderGeometry(.82, .82, 3.6, 20), iron); boiler.rotation.z = Math.PI / 2; boiler.position.set(.5, 1.55, 0); g.add(boiler);
    [-.4, .5, 1.4].forEach(x => { const band = new THREE.Mesh(new THREE.TorusGeometry(.84, .05, 6, 20), brass); band.rotation.y = Math.PI / 2; band.position.set(x, 1.55, 0); g.add(band); });
    const cab = new THREE.Mesh(new THREE.BoxGeometry(1.9, 2.3, 2), iron); cab.position.set(-1.9, 1.85, 0); g.add(cab);
    const cw = new THREE.Mesh(new THREE.BoxGeometry(1.92, .6, 1.4), winLit); cw.position.set(-1.9, 2.35, 0); g.add(cw);
    const roof = new THREE.Mesh(new THREE.BoxGeometry(2.3, .18, 2.3), redP); roof.position.set(-1.9, 3.08, 0); g.add(roof);
    const chim = new THREE.Mesh(new THREE.CylinderGeometry(.34, .22, 1.1, 12), iron); chim.position.set(1.75, 2.75, 0); g.add(chim);
    const dome = new THREE.Mesh(new THREE.SphereGeometry(.32, 12, 8), brass); dome.position.set(.6, 2.35, 0); g.add(dome);
    const front = new THREE.Mesh(new THREE.CylinderGeometry(.66, .66, .16, 20), redP); front.rotation.z = Math.PI / 2; front.position.set(2.35, 1.55, 0); g.add(front);
    const lampM = new THREE.MeshBasicMaterial({ color: 0xfff1c8 }); const lamp = new THREE.Mesh(new THREE.SphereGeometry(.2, 10, 8), lampM); lamp.position.set(2.48, 2.05, 0); g.add(lamp);
    const cow = new THREE.Mesh(new THREE.ConeGeometry(.7, .8, 4), redP); cow.rotation.z = Math.PI / 2; cow.position.set(2.6, .6, 0); cow.scale.set(1, 1, .6); g.add(cow);
    g.userData.chim = chim; g.userData.lamp = lamp;
  } else {
    const body = new THREE.Mesh(new THREE.BoxGeometry(4.6, 1.2, 2), blue); body.position.y = 1.1; g.add(body);
    const up = new THREE.Mesh(new THREE.BoxGeometry(4.6, .95, 2), cream); up.position.y = 2.17; g.add(up);
    const w = new THREE.Mesh(new THREE.BoxGeometry(4.1, .5, 2.03), winLit); w.position.y = 2.2; g.add(w);
    const roof = new THREE.Mesh(new THREE.CylinderGeometry(1.25, 1.25, 4.9, 18, 1, false, -Math.PI / 2, Math.PI), blue); roof.rotation.z = Math.PI / 2; roof.scale.set(1, .3, .86); roof.position.y = 2.64; g.add(roof);
  }
  [-1.4, 1.4].forEach(x => [-.85, .85].forEach(s => { const wh = new THREE.Mesh(new THREE.CylinderGeometry(.38, .38, .14, 14), iron); wh.rotation.x = Math.PI / 2; wh.position.set(x, .4, s); g.add(wh); }));
  g.traverse(o => { if (o.isMesh) o.castShadow = true; });
  train.add(g); cars.push(g); return g;
}
car(true); for (let i = 0; i < 4; i++) car(false);
world.add(train); pickable(train, 'train', new THREE.Vector3(0, 3, 0));
const head = new THREE.SpotLight(0xffe2a8, 0, 34, .45, .6, 1.2); head.position.set(2.5, 2, 0); head.target.position.set(10, 0, 0); cars[0].add(head, head.target);
const headGlow = glowSprite(0xffe7b0, 4); headGlow.position.set(2.6, 2.05, 0); cars[0].add(headGlow);
const TRN = { a: Math.PI * .62, v: .055, boost: 0 };
const puffs = Array.from({ length: 44 }, () => { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: PUFF, transparent: true, depthWrite: false, opacity: 0 })); s.visible = false; world.add(s); return { s, life: 0, k: 1, spin: 0 }; });
function puff(k = 1) { const p = puffs.find(p => p.life <= 0); if (!p) return; cars[0].userData.chim.getWorldPosition(p.s.position); world.worldToLocal(p.s.position); p.s.position.y += .7; p.life = 1; p.k = k; p.spin = (Math.random() - .5) * 1.4; p.s.material.rotation = Math.random() * 6; p.s.visible = true; }

/* ================= temple on carved plateau ================= */
const temple = new THREE.Group(); temple.position.set(TEMPLE.x, PLATEAU, TEMPLE.z); temple.rotation.y = .42; temple.scale.setScalar(1.15);
{
  const sl = M({ color: 0xe0c99c, roughness: .85 }), sm = M({ color: 0xcfae7b, roughness: .85 }), sd = M({ color: 0xab8a5c, roughness: .9 });
  const ledge = M({ color: 0xc66c3a, roughness: .7 }), dark = M({ color: 0x2b2420, roughness: 1 });
  const gold = M({ color: 0xd8a640, roughness: .28, metalness: 1, emissive: 0x6b4a10, emissiveIntensity: 0 });
  const add = (geo, m, x, y, z, ry = 0) => { const o = new THREE.Mesh(geo, m); o.position.set(x, y, z); o.rotation.y = ry; o.castShadow = o.receiveShadow = true; temple.add(o); return o; };
  add(new THREE.BoxGeometry(12.9, 4, 9.9), sd, 0, -1.6, 0);
  add(new THREE.BoxGeometry(12.5, .9, 9.5), sd, 0, .45, 0);
  for (let i = 0; i < 3; i++) add(new THREE.BoxGeometry(4.2, .3, .7), sd, 0, .15 + i * .3 - .3, 5.1 + (2 - i) * .55 - .55);
  add(new THREE.BoxGeometry(9.4, 3.2, 6.3), sl, 0, .9 + 1.6, 0);
  add(new THREE.BoxGeometry(1.7, 2.3, .2), dark, 0, .9 + 1.15, 3.16);
  for (let i = -3; i <= 3; i++) if (i) add(new THREE.BoxGeometry(.32, 2.8, .32), sm, i * 1.3, .9 + 1.4, 3.2);
  add(new THREE.BoxGeometry(10.1, .36, 7), ledge, 0, 4.28, 0);
  let y = 4.46; const bumps = [];
  for (let i = 0; i < 7; i++) {
    const w = 8.5 - i * .98, d = 5.5 - i * .58, hh = 1.62;
    add(new THREE.BoxGeometry(w, hh, d), i % 2 ? sm : sl, 0, y + hh / 2, 0);
    add(new THREE.BoxGeometry(w + .4, .18, d + .4), ledge, 0, y + hh + .09, 0);
    const n = Math.max(2, Math.floor(w / 1.05));
    for (let k = 0; k < n; k++) { const x = -w / 2 + .5 + k * (w - 1) / (n - 1); bumps.push([x, y + hh + .32, d / 2 + .05], [x, y + hh + .32, -d / 2 - .05]); }
    [[-1, 1], [1, 1], [-1, -1], [1, -1]].forEach(([sx, sz]) => bumps.push([sx * (w / 2), y + hh + .4, sz * (d / 2)]));
    y += hh + .18;
  }
  const bump = new THREE.InstancedMesh(new THREE.SphereGeometry(.24, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2), sm, bumps.length);
  bumps.forEach(([x, by, z], i) => { M4.makeTranslation(x, by, z); bump.setMatrixAt(i, M4); }); bump.castShadow = true; temple.add(bump);
  const vr = 1.25, vl = 2.4;
  const vault = add(new THREE.CylinderGeometry(vr, vr, vl, 20, 1, false, 0, Math.PI), sl, 0, y, 0); vault.rotation.z = Math.PI / 2;
  [-1, 1].forEach(s => { const cap = add(new THREE.CircleGeometry(vr, 20, 0, Math.PI), sl, s * vl / 2, y, 0, s * Math.PI / 2); cap.material = sl; });
  for (let k = -2; k <= 2; k++) { add(new THREE.SphereGeometry(.2, 10, 8), gold, k * .5, y + vr + .15, 0); add(new THREE.ConeGeometry(.15, .62, 10), gold, k * .5, y + vr + .55, 0); }
  // flag post
  add(new THREE.CylinderGeometry(.09, .13, 5.6, 8), gold, 5.2, .9 + 2.8, 3.9);
  const flag = add(new THREE.PlaneGeometry(1.2, .7), new THREE.MeshStandardMaterial({ color: 0xe4551c, side: THREE.DoubleSide }), 5.82, .9 + 5.1, 3.9);
  temple.userData.flag = flag;
  temple.userData.gold = gold;
}
const lamps = new THREE.Group(); temple.add(lamps);
const flameM = new THREE.MeshBasicMaterial({ color: 0xffc46b, transparent: true, opacity: 0 });
for (let i = 0; i < 13; i++) { const x = -5.6 + i * .93; const f = new THREE.Mesh(new THREE.SphereGeometry(.11, 8, 6), flameM); f.position.set(x, 1.02, 4.62); f.scale.y = 1.7; lamps.add(f); const g = glowSprite(0xffb050, 1.7); g.position.copy(f.position); lamps.add(g); }
const templeLight = new THREE.PointLight(0xffa64a, 0, 26, 1.8); templeLight.position.set(0, 3, 6.5); temple.add(templeLight);
world.add(temple); pickable(temple, 'temple', new THREE.Vector3(0, 20, 0));
let templeOn = 0, templeBoost = 0;
const sparks = { n: 90, pts: null, vel: [], life: 0 };
{ const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(new Float32Array(sparks.n * 3), 3));
  sparks.pts = new THREE.Points(g, new THREE.PointsMaterial({ map: GLOW, color: 0xffcf6a, size: .9, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false })); temple.add(sparks.pts); }
function burst() { const p = sparks.pts.geometry.attributes.position; sparks.vel = []; for (let i = 0; i < sparks.n; i++) { p.setXYZ(i, (Math.random() - .5) * 2, 15 + Math.random(), (Math.random() - .5) * 2); sparks.vel.push(new THREE.Vector3((Math.random() - .5) * 7, 4 + Math.random() * 6, (Math.random() - .5) * 7)); } p.needsUpdate = true; sparks.life = 1.6; }

/* ================= tower + panoramic lift ================= */
const FLOORS = 11, FH = 2.25, BASEY = 2.4;
const tower = new THREE.Group(); tower.position.set(PLAZA.x, 1.0, PLAZA.z); tower.rotation.y = -.5;
const lift = { y: 0, floor: 0, target: 0, wait: 2, doors: 0, dir: 1, forced: false };
const floorY = k => BASEY + k * FH;
{
  const concrete = M({ color: 0xd8d1c3, roughness: .8 }), conc2 = M({ color: 0xc4bcad, roughness: .85 });
  const glass = new THREE.MeshPhysicalMaterial({ color: 0x8fb2c2, roughness: .06, metalness: .25, transparent: true, opacity: .55, envMapIntensity: 1.4 }); envMats.push(glass);
  const steel = M({ color: 0x2a2f33, roughness: .35, metalness: .85 });
  const add = (geo, m, x, y, z) => { const o = new THREE.Mesh(geo, m); o.position.set(x, y, z); o.castShadow = o.receiveShadow = true; tower.add(o); return o; };
  add(new THREE.BoxGeometry(13, BASEY + 3, 12), conc2, 0, (BASEY - 3) / 2, -1);
  add(new THREE.BoxGeometry(13.6, .25, 12.6), concrete, 0, BASEY, -1);
  tower.userData.rooms = [];
  for (let k = 0; k < FLOORS; k++) {
    const y = floorY(k);
    add(new THREE.BoxGeometry(8.8, .32, 8.8), concrete, 0, y + .16, -1.6);
    const room = new THREE.Mesh(new THREE.BoxGeometry(7.6, FH - .5, 7.6), M({ color: 0x3a4248, emissive: 0xffd08a, emissiveIntensity: 0, roughness: .9 }));
    room.position.set(0, y + FH / 2 + .08, -1.6); tower.add(room); tower.userData.rooms.push({ m: room.material, lit: rnd() < .55 });
    const gl = new THREE.Mesh(new THREE.BoxGeometry(8.2, FH - .34, 8.2), glass); gl.position.set(0, y + FH / 2 + .14, -1.6); gl.castShadow = true; tower.add(gl);
  }
  const topY = floorY(FLOORS);
  add(new THREE.BoxGeometry(8.8, .45, 8.8), concrete, 0, topY + .2, -1.6);
  add(new THREE.BoxGeometry(5.6, 1.9, 5.6), conc2, 0, topY + 1.35, -2.2);
  const mull = new THREE.InstancedMesh(new THREE.BoxGeometry(.12, topY - BASEY, .12), steel, 16); let mi = 0;
  for (let s = -1; s <= 1; s += 2) for (let k = 0; k < 4; k++) { const off = -3.9 + k * 2.6; M4.makeTranslation(s * 4.12, (topY + BASEY) / 2, -1.6 + off); mull.setMatrixAt(mi++, M4); M4.makeTranslation(off, (topY + BASEY) / 2, -1.6 + s * 4.12); mull.setMatrixAt(mi++, M4); }
  mull.castShadow = true; tower.add(mull);
  add(new THREE.CylinderGeometry(.06, .06, 4, 6), steel, 1.6, topY + 3.6, -2.4);
  tower.userData.beacon = new THREE.Mesh(new THREE.SphereGeometry(.18, 8, 6), new THREE.MeshBasicMaterial({ color: 0xff3b30, transparent: true, opacity: 0 })); tower.userData.beacon.position.set(1.6, topY + 5.7, -2.4); tower.add(tower.userData.beacon);
  // shaft on the front face
  const SZ = 2.9 + 1.4, SH = topY + 2.4;
  const sGlass = new THREE.MeshPhysicalMaterial({ color: 0xbfd9e6, roughness: .04, metalness: .1, transparent: true, opacity: .16, depthWrite: false, envMapIntensity: 1.5 }); envMats.push(sGlass);
  const shaft = new THREE.Mesh(new THREE.BoxGeometry(3, SH, 2.8), sGlass); shaft.position.set(0, SH / 2 + BASEY - .1, SZ); tower.add(shaft);
  const frame = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), M({ color: 0xe4551c, roughness: .5, metalness: .4 }), 4 + (FLOORS + 2) * 4); let fi = 0;
  [[-1.5, -1.4], [1.5, -1.4], [-1.5, 1.4], [1.5, 1.4]].forEach(([x, z]) => { M4.compose(V.set(x, BASEY + SH / 2 - .1, SZ + z), Q.identity(), SV.set(.16, SH, .16)); frame.setMatrixAt(fi++, M4); });
  for (let k = 0; k <= FLOORS + 1; k++) { const y = BASEY + k * FH; [[0, -1.4, 3, .1], [0, 1.4, 3, .1]].forEach(([x, z, w, d]) => { M4.compose(V.set(x, y, SZ + z), Q.identity(), SV.set(w, .1, d)); frame.setMatrixAt(fi++, M4); }); [[-1.5, 0], [1.5, 0]].forEach(([x, z]) => { M4.compose(V.set(x, y, SZ + z), Q.identity(), SV.set(.1, .1, 2.8)); frame.setMatrixAt(fi++, M4); }); }
  frame.count = fi; frame.castShadow = true; tower.add(frame);
  add(new THREE.BoxGeometry(3.4, 1.4, 3.2), steel, 0, BASEY + SH + .5, SZ);
  // landing doors on the tower face
  tower.userData.landings = [];
  for (let k = 0; k <= FLOORS - 1; k++) {
    const y = floorY(k) + 1.05, grp = new THREE.Group(); grp.position.set(0, y, 2.62);
    const fr = new THREE.Mesh(new THREE.BoxGeometry(2.2, 2.1, .1), steel); grp.add(fr);
    const L = new THREE.Mesh(new THREE.BoxGeometry(.9, 1.9, .06), M({ color: 0x9aa3a8, roughness: .3, metalness: .9 })); L.position.set(-.46, 0, .07);
    const Rr = L.clone(); Rr.position.x = .46; grp.add(L, Rr); tower.add(grp); tower.userData.landings.push({ L, R: Rr });
  }
  // the car
  const carG = new THREE.Group(); carG.position.set(0, floorY(0), SZ);
  const cf = M({ color: 0x1c1f21, roughness: .4, metalness: .7 });
  const floorP = new THREE.Mesh(new THREE.BoxGeometry(2.5, .16, 2.3), cf); floorP.position.y = .08; carG.add(floorP);
  const ceil = new THREE.Mesh(new THREE.BoxGeometry(2.5, .22, 2.3), cf); ceil.position.y = 2.25; carG.add(ceil);
  const panel = new THREE.Mesh(new THREE.PlaneGeometry(2.1, 1.9), new THREE.MeshBasicMaterial({ color: 0xfff0d0, transparent: true, opacity: .0 })); panel.rotation.x = Math.PI / 2; panel.position.y = 2.13; carG.add(panel);
  const cGlass = new THREE.MeshPhysicalMaterial({ color: 0xd8ecf5, roughness: .02, transparent: true, opacity: .22, depthWrite: false }); envMats.push(cGlass);
  const cg = new THREE.Mesh(new THREE.BoxGeometry(2.4, 2, 2.2), cGlass); cg.position.y = 1.17; carG.add(cg);
  [[-1.2, -1.1], [1.2, -1.1], [-1.2, 1.1], [1.2, 1.1]].forEach(([x, z]) => { const p = new THREE.Mesh(new THREE.BoxGeometry(.1, 2.2, .1), M({ color: 0xe4551c, roughness: .45, metalness: .5 })); p.position.set(x, 1.15, z); carG.add(p); });
  const rail = new THREE.Mesh(new THREE.BoxGeometry(2.2, .05, .05), brass); rail.position.set(0, .95, 1.05); carG.add(rail);
  const dl = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.9, .05), M({ color: 0xb6bec3, roughness: .25, metalness: .9 })); dl.position.set(-.5, 1.1, -1.12);
  const dr = dl.clone(); dr.position.x = .5; carG.add(dl, dr);
  const person = new THREE.Group(); const body = new THREE.Mesh(new THREE.CapsuleGeometry(.22, .7, 4, 8), M({ color: 0xe4551c })); body.position.y = .75; const hd = new THREE.Mesh(new THREE.SphereGeometry(.18, 10, 8), M({ color: 0x5a3b28 })); hd.position.y = 1.4; person.add(body, hd); person.position.set(.4, .16, .3); carG.add(person);
  const carLight = new THREE.PointLight(0xffe0b0, 0, 9, 1.6); carLight.position.y = 1.6; carG.add(carLight);
  const carGlow = glowSprite(0xffd9a0, 6); carGlow.position.y = 1.4; carG.add(carGlow);
  carG.traverse(o => { if (o.isMesh && o.material !== cGlass && o !== panel) o.castShadow = true; });
  tower.add(carG);
  const cableM = M({ color: 0x1c1f21, metalness: .8, roughness: .3 });
  const cables = [-.4, .4].map(x => { const c = new THREE.Mesh(new THREE.CylinderGeometry(.025, .025, 1, 4), cableM); c.position.x = x; c.position.z = SZ; tower.add(c); return c; });
  const cw = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1.6, .5), steel); cw.position.set(0, 10, SZ - 1.05); tower.add(cw);
  Object.assign(tower.userData, { carG, dl, dr, cables, cw, carLight, carGlow, panel, SH, topY });
}
world.add(tower); pickable(tower, 'tower', new THREE.Vector3(0, 30, 0));

/* ================= wind turbines ================= */
const bladeShape = new THREE.Shape(); bladeShape.moveTo(0, 0); bladeShape.quadraticCurveTo(.62, 1.4, .3, 7.6); bladeShape.lineTo(.08, 8); bladeShape.quadraticCurveTo(-.24, 1.6, 0, 0);
const bladeGeo = new THREE.ExtrudeGeometry(bladeShape, { depth: .1, bevelEnabled: false }); bladeGeo.translate(-.15, .5, -.05);
const whiteM = M({ color: 0xf4f3ef, roughness: .45 }), redLamp = new THREE.MeshBasicMaterial({ color: 0xff3b30, transparent: true, opacity: 0 });
const turbines = [[31, -12], [35, -20], [25, -21]].map(([x, z], i) => {
  const g = new THREE.Group(); g.position.set(x, H(x, z) - .3, z); g.rotation.y = .35 + i * .08;
  const tw = new THREE.Mesh(new THREE.CylinderGeometry(.22, .5, 17, 12), whiteM); tw.position.y = 8.5; tw.castShadow = true; g.add(tw);
  const nac = new THREE.Mesh(new THREE.CapsuleGeometry(.5, 1.6, 4, 10), whiteM); nac.rotation.x = Math.PI / 2; nac.position.set(0, 17.2, -.2); nac.castShadow = true; g.add(nac);
  const rotor = new THREE.Group(); rotor.position.set(0, 17.2, 1.05); g.add(rotor);
  const hub = new THREE.Mesh(new THREE.ConeGeometry(.42, .9, 14), whiteM); hub.rotation.x = Math.PI / 2; hub.position.z = .2; rotor.add(hub);
  for (let k = 0; k < 3; k++) { const b = new THREE.Mesh(bladeGeo, whiteM); b.rotation.z = k * Math.PI * 2 / 3; b.castShadow = true; rotor.add(b); }
  const lamp = new THREE.Mesh(new THREE.SphereGeometry(.22, 8, 6), redLamp); lamp.position.set(0, 17.9, -.6); g.add(lamp);
  world.add(g); pickable(g, 'turbine', new THREE.Vector3(0, 24, 0)); return { g, rotor, v: .9 + i * .15, kick: 0 };
});

/* ================= vegetation ================= */
// palms (merged fronds, pinnate leaflets)
function frondGeo(L) {
  const pos = [], up = new THREE.Vector3(), P0 = new THREE.Vector3();
  const rach = t => new THREE.Vector3(0, L * (.3 * Math.sin(Math.PI * t * .55) - .55 * t * t), L * t);
  for (let i = 0; i < 26; i++) {
    const t = .06 + i / 26 * .92, p = rach(t), pn = rach(Math.min(1, t + .03)), dir = pn.clone().sub(p).normalize(), len = L * .26 * Math.pow(Math.sin(Math.PI * Math.min(1, t * 1.02)), .6) + .05;
    for (const s of [-1, 1]) {
      const out = new THREE.Vector3(s, -.5 - t * .4, .3).normalize().multiplyScalar(len), tip = p.clone().add(out), a = p.clone().addScaledVector(dir, -.04 * L), b = p.clone().addScaledVector(dir, .04 * L);
      pos.push(a.x, a.y, a.z, tip.x, tip.y, tip.z, b.x, b.y, b.z);
    }
  }
  const st = []; for (let i = 0; i < 20; i++) { const t0 = i / 20, t1 = (i + 1) / 20, p0 = rach(t0), p1 = rach(t1), w = .03 * L * (1 - t0); st.push(p0.x - w, p0.y, p0.z, p1.x - w * .6, p1.y, p1.z, p0.x + w, p0.y, p0.z, p0.x + w, p0.y, p0.z, p1.x - w * .6, p1.y, p1.z, p1.x + w * .6, p1.y, p1.z); }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos.concat(st), 3)); g.computeVertexNormals(); return g;
}
const frondM = M({ color: 0x4d8436, roughness: .75, side: THREE.DoubleSide }), barkM = M({ color: 0x8b7258, roughness: 1 }), nutM = M({ color: 0x7c7a2c, roughness: .6 });
const palms = [];
function palm(x, z, h, lean, ry) {
  const g = new THREE.Group(); g.position.set(x, H(x, z) - .1, z); g.rotation.y = ry;
  const curve = new THREE.CatmullRomCurve3([new THREE.Vector3(0, 0, 0), new THREE.Vector3(lean * h * .12, h * .35, 0), new THREE.Vector3(lean * h * .5, h * .75, 0), new THREE.Vector3(lean * h, h, 0)]);
  const segs = []; const n = 10;
  for (let i = 0; i < n; i++) { const a = curve.getPoint(i / n), b = curve.getPoint((i + 1) / n), len = a.distanceTo(b), r0 = h * (.034 - i * .0015), r1 = h * (.032 - i * .0015);
    const geo = new THREE.CylinderGeometry(r1, r0 * 1.06, len * 1.02, 8); const mid = a.clone().add(b).multiplyScalar(.5); const dir = b.clone().sub(a).normalize(); Q.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir); M4.compose(mid, Q, SV.set(1, 1, 1)); geo.applyMatrix4(M4); segs.push(geo); }
  const trunk = new THREE.Mesh(mergeGeometries(segs), barkM); trunk.castShadow = true; g.add(trunk);
  const crown = new THREE.Group(); crown.position.copy(curve.getPoint(1)); g.add(crown);
  const fronds = []; const nf = 13;
  for (let i = 0; i < nf; i++) { const fg = frondGeo(h * (.42 + (i % 3) * .05)); const ry2 = i / nf * Math.PI * 2 + (i % 2) * .25, rx = -(.05 + (i % 4) * .12); M4.makeRotationFromEuler(E.set(rx, ry2, 0, 'YXZ')); fg.applyMatrix4(M4); fronds.push(fg); }
  const fm = new THREE.Mesh(mergeGeometries(fronds), frondM); fm.castShadow = true; crown.add(fm);
  for (let i = 0; i < 5; i++) { const c = new THREE.Mesh(new THREE.SphereGeometry(h * .028, 10, 8), nutM); c.position.set(Math.cos(i * 1.25) * h * .035, -h * .035, Math.sin(i * 1.25) * h * .035); crown.add(c); }
  world.add(g); palms.push({ g, crown, x, z, ph: rnd() * 6, kick: 0 });
}
[[-6, 26, 9, .14, .2], [-24, 33, 8.5, -.1, 1.4], [-10, 35, 7.5, .1, 2.4], [18, 24, 9.5, -.16, .8], [14, 8, 8, .12, 2], [-4, 9, 8.6, -.12, 3.1], [24, 34, 7.5, .1, 1], [38, 18, 8, -.1, .5],
 [-36, 14, 8.5, .1, 2.2], [-28, 22, 7, -.08, 1.1], [3, 31, 7.8, .14, 1.7], [-40, -14, 7, .1, .4], [9, -8, 7.5, -.1, 2.6], [-14, 13, 7.2, .1, 1.9]].forEach(a => palm(...a));
// broadleaf trees (instanced, low-poly)
{
  const pts = [];
  let guard = 0;
  while (pts.length < (small ? 90 : 140) && guard++ < 6000) {
    const a = rnd() * Math.PI * 2, r = Math.sqrt(rnd()) * 44, x = Math.cos(a) * r, z = Math.sin(a) * r, y = H(x, z);
    if (Math.hypot(x - LAKE.x, z - LAKE.z) < 13.5 || Math.hypot(x - PLAZA.x, z - PLAZA.z) < 9.5 || Math.hypot(x - VILLAGE.x, z - VILLAGE.z) < 11 || Math.hypot(x - TEMPLE.x, z - TEMPLE.z) < 8.5 || Math.hypot(x - TEA.x, z - TEA.z) < 12.5 || y > 21) continue;
    if (turbines.some(t => Math.hypot(x - t.g.position.x, z - t.g.position.z) < 3)) continue;
    pts.push([x, y, z, .7 + rnd() * .7]);
  }
  const trunkI = new THREE.InstancedMesh(new THREE.CylinderGeometry(.12, .2, 1.6, 6), barkM, pts.length);
  const canopy = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1, 1), M({ color: 0xffffff, roughness: .85, flatShading: true }), pts.length);
  const greens = [0x3f6f35, 0x4f7f3a, 0x5d8a3f, 0x355f30, 0x6b8f44].map(col);
  pts.forEach(([x, y, z, s], i) => {
    M4.compose(V.set(x, y + .8 * s, z), Q.identity(), SV.set(s, s, s)); trunkI.setMatrixAt(i, M4);
    M4.compose(V.set(x, y + 2.2 * s, z), Q.setFromEuler(E.set(0, rnd() * 6, 0)), SV.set(1.5 * s, 1.75 * s, 1.5 * s)); canopy.setMatrixAt(i, M4); canopy.setColorAt(i, greens[i % greens.length]);
  });
  trunkI.castShadow = canopy.castShadow = true; canopy.receiveShadow = true; world.add(trunkI, canopy);
}
// tea terraces
{
  const pts = [];
  for (let r = 1.6; r < 11.5; r += 1.25) { const n = Math.floor(2 * Math.PI * r / 1.15); for (let k = 0; k < n; k++) { const a = k / n * Math.PI * 2 + r, x = TEA.x + Math.cos(a) * r, z = TEA.z + Math.sin(a) * r; if (Math.hypot(x, z) > 44) continue; pts.push([x, H(x, z), z]); } }
  const bush = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1, 2), M({ color: 0x3f7a35, roughness: .9 }), pts.length);
  pts.forEach(([x, y, z], i) => { const s = .5 + rnd() * .15; M4.compose(V.set(x, y + .3, z), Q.identity(), SV.set(s * 1.1, s * .7, s * 1.1)); bush.setMatrixAt(i, M4); });
  bush.castShadow = bush.receiveShadow = true; world.add(bush);
}
// village houses
const houseWin = [];
{
  const wall = M({ color: 0xf2e9d6, roughness: .9 }), roofM = M({ color: 0xc4532a, roughness: .7 }), door = M({ color: 0x5a3b28 });
  const tri = new THREE.Shape(); tri.moveTo(-1.6, 0); tri.lineTo(1.6, 0); tri.lineTo(0, 1.25); tri.lineTo(-1.6, 0);
  const roofGeo = new THREE.ExtrudeGeometry(tri, { depth: 3.2, bevelEnabled: false }); roofGeo.translate(0, 0, -1.6);
  [[-20, 22, .3], [-14, 24, -.2], [-22, 29, .9], [-16, 31, .1], [-11, 28, -.5], [-25, 25, 1.2], [-18, 35, .4], [-9, 21, .7]].forEach(([x, z, ry]) => {
    const g = new THREE.Group(); g.position.set(x, H(x, z), z); g.rotation.y = ry;
    const w = new THREE.Mesh(new THREE.BoxGeometry(2.8, 2.8, 2.8), wall); w.position.y = .4; g.add(w);
    const plin = new THREE.Mesh(new THREE.BoxGeometry(3.2, .3, 3.2), door); plin.position.y = -.05; g.add(plin);
    const rf = new THREE.Mesh(roofGeo, roofM); rf.position.y = 1.8; rf.rotation.y = Math.PI / 2; g.add(rf);
    const d = new THREE.Mesh(new THREE.BoxGeometry(.6, 1.1, .06), door); d.position.set(0, .55, 1.42); g.add(d);
    const wm = new THREE.MeshStandardMaterial({ color: 0x3b4650, emissive: 0xffc06a, emissiveIntensity: 0 }); houseWin.push({ m: wm, lit: rnd() < .8, ph: rnd() * 6 });
    [-.85, .85].forEach(px => { const wn = new THREE.Mesh(new THREE.BoxGeometry(.5, .5, .06), wm); wn.position.set(px, 1.05, 1.42); g.add(wn); });
    g.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    world.add(g);
  });
}

/* ================= clouds (cast shadows) ================= */
const cloudM = M({ color: 0xffffff, roughness: 1, emissive: 0xffffff, emissiveIntensity: .05 });
const clouds = Array.from({ length: 5 }, (_, i) => {
  const g = new THREE.Group(), n = 5 + (i % 3);
  for (let k = 0; k < n; k++) { const b = new THREE.Mesh(new THREE.IcosahedronGeometry(1, 3), cloudM); const s = 2.4 + rnd() * 2.2; b.scale.set(s * 1.25, s * .8, s); b.position.set((k - n / 2) * 2.6, rnd() * 1.2, rnd() * 2.4 - 1.2); b.castShadow = true; g.add(b); }
  const ang = i / 5 * Math.PI * 2, rad = 50 + (i % 2) * 8; g.userData = { ang, rad, y: 46 + (i % 3) * 4, v: .025 + rnd() * .02 }; g.scale.setScalar(.8); world.add(g); return g;
});

/* ================= birds ================= */
const birdM = M({ color: 0x2b2f33, roughness: .8, side: THREE.DoubleSide });
const wingGeo = new THREE.BufferGeometry(); wingGeo.setAttribute('position', new THREE.Float32BufferAttribute([0, 0, -.25, 0, 0, .3, 1.2, 0, -.05], 3)); wingGeo.computeVertexNormals();
const flock = new THREE.Group(); const birds = [];
for (let i = 0; i < 7; i++) {
  const b = new THREE.Group(); const bd = new THREE.Mesh(new THREE.ConeGeometry(.16, .9, 6), birdM); bd.rotation.x = Math.PI / 2; b.add(bd);
  const wl = new THREE.Mesh(wingGeo, birdM), wr = new THREE.Mesh(wingGeo, birdM); wr.scale.x = -1; b.add(wl, wr);
  b.position.set((i % 3 - 1) * 2.2 - (i > 3 ? 1 : 0), (i % 2) * .8, -Math.floor(i / 2) * 1.6); flock.add(b); birds.push({ b, wl, wr, ph: rnd() * 6 });
}
world.add(flock);

/* ================= GPU particles ================= */
function particleSystem(count, spread, color, size, opts = {}) {
  const pos = new Float32Array(count * 3), ph = new Float32Array(count), sc = new Float32Array(count);
  for (let i = 0; i < count; i++) { const p = spread(i); pos.set(p, i * 3); ph[i] = Math.random(); sc[i] = .5 + Math.random(); }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('aPhase', new THREE.BufferAttribute(ph, 1)); g.setAttribute('aScale', new THREE.BufferAttribute(sc, 1));
  const m = new THREE.ShaderMaterial({
    uniforms: { uTime: { value: 0 }, uOpacity: { value: 0 }, uColor: { value: col(color) }, uPointer: { value: new THREE.Vector3(1e4, 0, 1e4) }, uSize: { value: size * renderer.getPixelRatio() }, uDrift: { value: opts.drift || 1 }, uPull: { value: opts.pull || 0 }, uBlink: { value: opts.blink ?? 1 } },
    vertexShader: `attribute float aPhase; attribute float aScale; uniform float uTime, uSize, uDrift, uPull, uBlink; uniform vec3 uPointer; varying float vB;
      void main(){ vec3 p = position; float t = uTime * uDrift;
        p.x += sin(t * .6 + aPhase * 31.) * 1.7 + sin(t * .23 + aPhase * 7.) * 1.1;
        p.z += cos(t * .5 + aPhase * 17.) * 1.7;
        p.y += sin(t * .9 + aPhase * 11.) * .8;
        vec4 wp = modelMatrix * vec4(p, 1.0);
        vec3 d = uPointer - wp.xyz; float dist = length(d); wp.xyz += d * uPull * smoothstep(16., 2., dist) * .55;
        vB = mix(1., pow(.5 + .5 * sin(uTime * 2.6 + aPhase * 40.), 2.5), uBlink);
        vec4 mv = viewMatrix * wp; gl_Position = projectionMatrix * mv; gl_PointSize = uSize * aScale * (90. / -mv.z); }`,
    fragmentShader: `uniform vec3 uColor; uniform float uOpacity; varying float vB;
      void main(){ float d = length(gl_PointCoord - .5); float core = smoothstep(.5, .0, d); float a = core * core * (.2 + .8 * vB); gl_FragColor = vec4(uColor * (1. + vB * .8), a * uOpacity); }`,
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending
  });
  const pts = new THREE.Points(g, m); pts.frustumCulled = false; world.add(pts); return m;
}
const ffMat = particleSystem(small ? 90 : 160, () => { const a = Math.random() * Math.PI * 2, r = 8 + Math.random() * 36, x = Math.cos(a) * r, z = Math.sin(a) * r; return [x, H(x, z) + 1 + Math.random() * 3.5, z]; }, 0xd8ff8a, 7, { pull: 1, drift: 1 });
const moteMat = particleSystem(small ? 70 : 130, () => { const a = Math.random() * Math.PI * 2, r = Math.random() * 46, x = Math.cos(a) * r, z = Math.sin(a) * r; return [x, H(x, z) + 2 + Math.random() * 14, z]; }, 0xfff1cf, 3.2, { drift: .35, blink: .4 });
const glintMat = particleSystem(40, () => { const a = Math.random() * Math.PI * 2, r = Math.sqrt(Math.random()) * 10; return [LAKE.x + Math.cos(a) * r, .55, LAKE.z + Math.sin(a) * r]; }, 0xffffff, 4, { drift: .08, blink: 1 });
// stars above the diorama
const starMat = (() => {
  const n = 900, pos = new Float32Array(n * 3), ph = new Float32Array(n), sc = new Float32Array(n);
  for (let i = 0; i < n; i++) { const th = Math.random() * Math.PI * 2, el = .08 + Math.random() * .9, r = 420; pos.set([Math.cos(th) * Math.cos(el) * r, Math.sin(el) * r * .8 + 10, Math.sin(th) * Math.cos(el) * r - 120], i * 3); ph[i] = Math.random(); sc[i] = .4 + Math.random() * .9; }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('aPhase', new THREE.BufferAttribute(ph, 1)); g.setAttribute('aScale', new THREE.BufferAttribute(sc, 1));
  const m = new THREE.ShaderMaterial({ uniforms: { uTime: { value: 0 }, uOpacity: { value: 0 }, uSize: { value: 2.2 * renderer.getPixelRatio() } },
    vertexShader: 'attribute float aPhase; attribute float aScale; uniform float uTime, uSize; varying float vT; void main(){ vT = .55 + .45 * sin(uTime * (1. + aPhase * 2.) + aPhase * 50.); vec4 mv = modelViewMatrix * vec4(position,1.); gl_Position = projectionMatrix * mv; gl_PointSize = uSize * aScale; }',
    fragmentShader: 'uniform float uOpacity; varying float vT; void main(){ float d = length(gl_PointCoord - .5); gl_FragColor = vec4(vec3(1.), smoothstep(.5,.1,d) * uOpacity * vT); }',
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  const p = new THREE.Points(g, m); p.frustumCulled = false; scene.add(p); return m;
})();
const shoots = [];
function shoot(from) {
  const s = new THREE.Mesh(new THREE.PlaneGeometry(26, .35), new THREE.MeshBasicMaterial({ map: softTex(64, [[0, 1], [1, 0]]), color: 0xffffff, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
  s.position.copy(from); s.lookAt(camera.position); s.rotateZ(-.4); scene.add(s); shoots.push({ s, life: 1, v: new THREE.Vector3(140, -60, 0) });
}

/* ================= sky bodies + orbit ================= */
const ORB = { cx: 0, cy: BAND - 2, cz: -42, rx: 74, ry: 52 };
const orbitPos = (a) => new THREE.Vector3(ORB.cx - Math.cos(a) * ORB.rx, ORB.cy + Math.sin(a) * ORB.ry, ORB.cz);
const TAU = Math.PI * 2;
const orbitLine = (() => {
  const mk = (a0, a1, op) => { const pts = []; for (let i = 0; i <= 160; i++) pts.push(orbitPos(a0 + (a1 - a0) * i / 160)); const g = new THREE.BufferGeometry().setFromPoints(pts); const l = new THREE.Line(g, new THREE.LineDashedMaterial({ color: 0xe4551c, dashSize: 1.4, gapSize: 1.2, transparent: true, opacity: op, depthTest: false })); l.computeLineDistances(); l.renderOrder = 5; scene.add(l); return l; };
  const upper = mk(0, Math.PI, .55), lower = mk(Math.PI, TAU, .22);
  const tick = new THREE.InstancedMesh(new THREE.SphereGeometry(.5, 8, 6), new THREE.MeshBasicMaterial({ color: 0xe4551c, depthTest: false }), 4); tick.renderOrder = 6;
  [0, .5, 1, 1.5].forEach((k, i) => { M4.makeTranslation(...orbitPos(k * Math.PI).toArray()); tick.setMatrixAt(i, M4); }); scene.add(tick);
  return { upper, lower };
})();
const ghostMat = new THREE.MeshBasicMaterial({ color: 0xe4551c, transparent: true, opacity: 0, side: THREE.DoubleSide, depthTest: false });
const ghost = id => { const m = new THREE.Mesh(new THREE.RingGeometry(3.2, 3.7, 48), ghostMat.clone()); m.renderOrder = 7; m.userData.ghost = id; return m; };
const sun = new THREE.Mesh(new THREE.SphereGeometry(4.2, 32, 16), new THREE.MeshBasicMaterial({ color: 0xfff0c8, transparent: true }));
const sunGhost = ghost('sun'); sun.add(sunGhost);
const sunHalo = glowSprite(0xffc27a, 44, .9); sun.add(sunHalo);
const sunRing = new THREE.Mesh(new THREE.RingGeometry(5.6, 5.9, 64), new THREE.MeshBasicMaterial({ color: 0xe4551c, transparent: true, opacity: .8, side: THREE.DoubleSide })); sun.add(sunRing);
scene.add(sun); pickable(sun, 'sun', new THREE.Vector3(0, 7, 0));
const hitMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false });
const sunHit = new THREE.Mesh(new THREE.SphereGeometry(11, 12, 8), hitMat); sunHit.userData.body = 'sun'; sun.add(sunHit);
const moonTex = (() => { const c = document.createElement('canvas'); c.width = c.height = 256; const x = c.getContext('2d'); x.fillStyle = '#eef0f6'; x.fillRect(0, 0, 256, 256); for (let i = 0; i < 40; i++) { const r = 5 + Math.random() * 22; x.fillStyle = `rgba(140,150,175,${.1 + Math.random() * .2})`; x.beginPath(); x.arc(Math.random() * 256, Math.random() * 256, r, 0, 7); x.fill(); } const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; })();
const moon = new THREE.Mesh(new THREE.SphereGeometry(3.4, 32, 16), new THREE.MeshStandardMaterial({ map: moonTex, emissive: 0xdfe6ff, emissiveMap: moonTex, emissiveIntensity: .9, roughness: 1, transparent: true }));
const moonGhost = ghost('moon'); moon.add(moonGhost);
const moonHalo = glowSprite(0xa9bcff, 26, .6); moon.add(moonHalo);
scene.add(moon); pickable(moon, 'moon', new THREE.Vector3(0, 6, 0));
const moonHit = new THREE.Mesh(new THREE.SphereGeometry(10, 12, 8), hitMat); moonHit.userData.body = 'moon'; moon.add(moonHit);

/* ================= lights ================= */
const hemi = new THREE.HemisphereLight(0xdfe8ff, 0x6b5a3e, .6); scene.add(hemi);
const sunL = new THREE.DirectionalLight(0xffffff, 3); sunL.castShadow = true;
sunL.shadow.mapSize.set(small ? 1024 : 2048, small ? 1024 : 2048);
Object.assign(sunL.shadow.camera, { left: -80, right: 80, top: 80, bottom: -80, near: 10, far: 360 });
sunL.shadow.bias = -.0004; sunL.shadow.normalBias = .035; sunL.shadow.radius = 3;
scene.add(sunL, sunL.target);
const moonL = new THREE.DirectionalLight(0x9fb4ff, .5); scene.add(moonL);

/* ================= framing ================= */
const camDir = new THREE.Vector3(0, .5, 1).normalize();
function resize() {
  const W = hero.clientWidth, Hh = hero.clientHeight, hr = hero.getBoundingClientRect(), sr = host.getBoundingClientRect();
  const w = sr.width, h = sr.height, a = w / h, sx = sr.left - hr.left, sy = sr.top - hr.top;
  renderer.setSize(W, Hh, false); camera.aspect = a; camera.setViewOffset(w, h, -sx, -sy, W, Hh);
  camera.fov = a < .85 ? 42 : 34; camera.updateProjectionMatrix();
  const vh = THREE.MathUtils.degToRad(camera.fov / 2), hh = Math.atan(Math.tan(vh) * a);
  const dist = Math.max(76 / Math.tan(hh), 62 / Math.tan(vh)) * (a < .9 ? .92 : 1);
  camera.position.copy(TARGET).addScaledVector(camDir, dist); camera.lookAt(TARGET); camera.userData.dist = dist;
  starMat.uniforms.uSize.value = 2.2 * renderer.getPixelRatio();
}
const ro = new ResizeObserver(resize); ro.observe(host); ro.observe(hero); resize();

/* ================= time look ================= */
const white = new THREE.Color(1, 1, 1), warm = new THREE.Color(1, .55, .3), tmp = new THREE.Color();
let day = 1, night = 0, lastEnv = -1;
function look(t) {
  day = RR.daylight(t); night = 1 - day; const w = RR.warmth(t);
  const sa = ((t - 6) / 12) * Math.PI, ma = sa + Math.PI;
  const sp = orbitPos(sa), mp = orbitPos(ma);
  const sEl = Math.sin(sa), mEl = Math.sin(ma);
  const sOn = smooth(-.08, .06, sEl), mOn = smooth(-.08, .06, mEl);
  sun.position.copy(sp); moon.position.copy(mp);
  sun.material.opacity = sOn; sunRing.material.opacity = .8 * sOn; sunGhost.material.opacity = .85 * (1 - sOn);
  moon.material.opacity = mOn; moonHalo.material.opacity = .6 * mOn * (.4 + night * .6); moonGhost.material.opacity = .85 * (1 - mOn);
  sunGhost.lookAt(camera.position); moonGhost.lookAt(camera.position);
  sun.material.color.copy(white).lerp(warm, Math.min(1, w * 1.1)); sunHalo.material.color.copy(sun.material.color).multiplyScalar(.9);
  sunRing.lookAt(camera.position); sunHalo.material.opacity = (.55 + w * .45) * sOn;
  const up = smooth(.0, .32, sEl);
  sunL.position.copy(sp).multiplyScalar(1.6); sunL.position.y = Math.max(sunL.position.y, 6); sunL.target.position.set(0, 0, 0);
  sunL.intensity = 3.4 * up; sunL.color.copy(white).lerp(warm, Math.min(1, w * .95));
  moonL.position.copy(mp).multiplyScalar(1.6); moonL.intensity = .65 * smooth(.0, .3, mEl) * (1 - up);
  hemi.intensity = .14 + day * .6; hemi.color.copy(night > .5 ? tmp.setRGB(.45, .52, .85) : white).lerp(warm, w * .55);
  hemi.groundColor.setRGB(.36 * (.4 + day * .6), .3 * (.4 + day * .6), .22 * (.4 + day * .6));
  const env = Math.round((.08 + day * .6) * 20) / 20;
  if (env !== lastEnv) { lastEnv = env; envMats.forEach(m => m.envMapIntensity = env * (m.userData.envBoost || 1)); }
  renderer.toneMappingExposure = 1.02 - night * .08;
  contourU.uLine.value.set(night > .5 ? 0x9fb3bb : 0x3d4f57); contourU.uLineAmt.value = .2 + night * .08;
  orbitLine.upper.material.opacity = .35 + day * .3; orbitLine.lower.material.opacity = .14 + day * .1;
  cloudM.color.copy(white).lerp(warm, w * .35).multiplyScalar(.35 + .65 * day); cloudM.emissive.copy(night > .5 ? tmp.setRGB(.15, .18, .3) : white); cloudM.emissiveIntensity = .05 + night * .3;
  winLit.emissiveIntensity = night * 2.2; redLamp.opacity = night > .4 ? 1 : 0; tower.userData.beacon.material.opacity = redLamp.opacity;
  head.intensity = night * 70; headGlow.material.opacity = night * .9;
  starMat.uniforms.uOpacity.value = night * night;
  ffMat.uniforms.uOpacity.value = smooth(.45, .9, night);
  moteMat.uniforms.uOpacity.value = day * .55 * (.5 + w);
  glintMat.uniforms.uOpacity.value = day * .9;
  houseWin.forEach(hw => hw.m.emissiveIntensity = hw.lit ? night * 2.6 : 0);
  tower.userData.rooms.forEach((r, i) => r.m.emissiveIntensity = r.lit ? night * (1.6 + (i % 3) * .3) : 0);
  const U = tower.userData; U.carLight.intensity = night * 14; U.carGlow.material.opacity = night * .55; U.panel.material.opacity = .4 + night * .6;
}

/* ================= interaction ================= */
const ray = new THREE.Raycaster(), ndc = new THREE.Vector2(), orbitPlane = new THREE.Plane(new THREE.Vector3(0, 0, 1), -ORB.cz), hit = new THREE.Vector3(), groundPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -2);
const pointer = { in: false, x: 0, y: 0, world: new THREE.Vector3(1e4, 0, 1e4) };
const rot = { y: 0, target: 0, v: 0, drag: false, lastX: 0, idle: 0 };
const anno = document.getElementById('anno'), annoT = anno.querySelector('b'), annoS = anno.querySelector('span');
const sunTag = document.getElementById('sunTag'), moonTag = document.getElementById('moonTag'), hourTags = [...document.querySelectorAll('.hour-tag')];
let drag = null, down = null, hover = null;
const LABELS = {
  train: ['Nilgiri mountain railway', 'Click to whistle'], temple: ['Hill temple', 'Lamps lit after dusk · click'], tower: ['Panoramic lift', 'Level 00 · click to ride'],
  turbine: ['Wind farm', 'Click to spin'], lake: ['Valley lake', 'Click for ripples'], sun: ['Sun', 'Drag around the orbit · 24 h'], moon: ['Moon', 'Drag around the orbit · 24 h'], land: null
};
function setNdc(e) { const r = hero.getBoundingClientRect(); ndc.set((e.clientX - r.left) / r.width * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1); }
function pickAt() {
  ray.setFromCamera(ndc, camera);
  const bh = ray.intersectObjects([sunHit, moonHit], false);
  if (bh.length) { const id = bh[0].object.userData.body; return { id, obj: id === 'sun' ? sun : moon, point: bh[0].point }; }
  const hits = ray.intersectObjects(pickables.filter(o => o !== sun && o !== moon), true);
  for (const h of hits) { let o = h.object; while (o && !o.userData.pick) o = o.parent; if (o) return { id: o.userData.pick, obj: o, point: h.point }; }
  return null;
}
hero.addEventListener('pointermove', e => {
  setNdc(e); pointer.in = true; pointer.x = ndc.x; pointer.y = ndc.y;
  ray.setFromCamera(ndc, camera); if (ray.ray.intersectPlane(groundPlane, hit)) pointer.world.copy(hit);
  if (drag) {
    if (ray.ray.intersectPlane(orbitPlane, hit)) { let a = Math.atan2((hit.y - ORB.cy) / ORB.ry, -(hit.x - ORB.cx) / ORB.rx); if (a < 0) a += TAU; RR.setManual(((drag === 'sun' ? 6 : 18) + a / Math.PI * 12) % 24); }
    e.preventDefault(); return;
  }
  if (rot.drag) { const dx = e.clientX - rot.lastX; rot.lastX = e.clientX; rot.target = Math.max(-1.1, Math.min(1.1, rot.target + dx * .006)); rot.idle = 0; return; }
  const p = pickAt(); hover = p && LABELS[p.id] ? p : null;
  const overCopy = !!e.target.closest('.copy');
  hero.style.cursor = hover ? (p.id === 'sun' || p.id === 'moon' ? 'grab' : 'pointer') : (overCopy || !p ? '' : 'grab');
});
hero.addEventListener('pointerleave', () => { if (drag) return; pointer.in = false; hover = null; pointer.world.set(1e4, 0, 1e4); });
hero.addEventListener('pointerdown', e => {
  if (e.target.closest('a,button,input,label,.tb,.hints')) { down = null; return; }
  setNdc(e); const p = pickAt(); down = { x: e.clientX, y: e.clientY, p };
  const inCopy = !!e.target.closest('.copy');
  if (p && (p.id === 'sun' || p.id === 'moon')) { drag = p.id; hero.setPointerCapture(e.pointerId); hero.style.cursor = 'grabbing'; e.preventDefault(); }
  else if (!inCopy && (p || e.target.closest('#stage3d'))) { rot.drag = true; rot.lastX = e.clientX; hero.setPointerCapture(e.pointerId); }
  else if (inCopy && !p) down = null;
});
hero.addEventListener('pointerup', e => {
  const moved = down ? Math.hypot(e.clientX - down.x, e.clientY - down.y) : 99;
  if (drag) { drag = null; hover = null; RR.egg('sun'); RR.hideHint(); hero.style.cursor = ''; return; }
  rot.drag = false; if (moved > 7 || !down) return;
  RR.hideHint(); const p = down.p, id = p?.id;
  if (id === 'train') { RR.sfx.whistle(); TRN.boost = .12; for (let i = 0; i < 10; i++) setTimeout(() => puff(1.8), i * 60); if (!RR.egg('train')) RR.toast('Whistle!', 1300); }
  else if (id === 'turbine') { RR.sfx.whoosh(); turbines.forEach(t => t.kick = 8); RR.egg('turbine'); }
  else if (id === 'tower') { lift.target = FLOORS - 1; lift.forced = true; lift.wait = 0; lift.riding = true; if (lift.doors > .05) RR.sfx.doors(); RR.toast('Going up to level ' + String(FLOORS - 1).padStart(2, '0') + '…', 1500); }
  else if (id === 'temple') { if (day < .5) { templeBoost = 1; burst(); RR.sfx.bell(); RR.egg('temple'); } else RR.toast('The lamps are lit after dusk. Drag the sun down to see them.'); }
  else if (id === 'lake') { const lp = world.worldToLocal(p.point.clone()); ripple(lp.x, lp.z); RR.sfx.plop(); }
  else if (!p && day < .45) { ray.setFromCamera(ndc, camera); shoot(ray.ray.at(260, new THREE.Vector3())); RR.sfx.twinkle(); RR.egg('star'); }
});
hero.addEventListener('pointercancel', () => { drag = null; rot.drag = false; });

/* ================= loop ================= */
let visible = true; new IntersectionObserver(([e]) => visible = e.isIntersecting).observe(hero);
const clock = new THREE.Clock(); let el = 0, first = true;
const proj = new THREE.Vector3();
function screen(v) { proj.copy(v).project(camera); const r = hero.getBoundingClientRect(); return [(proj.x + 1) / 2 * r.width, (1 - proj.y) / 2 * r.height, proj.z < 1]; }
function frame() {
  requestAnimationFrame(frame);
  const dt = Math.min(clock.getDelta(), .05);
  if (!visible || document.hidden) return;
  el += dt; const m = reduce ? 0 : 1, t = RR.T.t;
  look(t);
  // world rotation: drag + gentle idle sway
  rot.idle += dt; if (!rot.drag && rot.idle > 4 && m) rot.target += (Math.sin(el * .12) * .18 - rot.target) * .004;
  rot.y += (rot.target - rot.y) * .08; world.rotation.y = rot.y;
  // pointer parallax on camera
  const d = camera.userData.dist || 190; const off = pointer.in && !rot.drag && !drag ? pointer.x * 6 * m : 0;
  V.copy(TARGET).addScaledVector(camDir, d); V.x += off; V.y += (pointer.in ? pointer.y * 3 * m : 0);
  camera.position.lerp(V, .05); camera.lookAt(TARGET);
  [ffMat, moteMat, glintMat, starMat].forEach(mm => mm.uniforms.uTime.value = el);
  const pw = world.worldToLocal(pointer.world.clone()); ffMat.uniforms.uPointer.value.copy(pointer.world);
  // palms
  for (const p of palms) { const near = pointer.in && Math.hypot(pw.x - p.x, pw.z - p.z) < 9 ? 1 : 0; p.kick += (near - p.kick) * .05; p.crown.rotation.z = Math.sin(el * 1.2 + p.ph) * (.03 + p.kick * .08) * m; p.crown.rotation.x = Math.cos(el * .9 + p.ph) * (.025 + p.kick * .05) * m; }
  // turbines
  turbines.forEach(tb => { tb.kick *= .985; tb.rotor.rotation.z -= (tb.v + tb.kick) * dt * m; });
  // train loop
  TRN.boost *= .985; TRN.a += (TRN.v + TRN.boost) * dt * m;
  cars.forEach((c, i) => { const a = TRN.a - i * .105 - (i ? .012 : 0); c.position.set(Math.cos(a) * TR_R, railY, Math.sin(a) * TR_R); c.rotation.y = -a - Math.PI / 2; });
  if (m && Math.random() < dt * (7 + TRN.boost * 80)) puff(1);
  for (const p of puffs) if (p.life > 0) { p.life -= dt * .38; p.s.position.y += dt * 2.2; const s = (1 - p.life) * 5.5 * p.k + 1; p.s.scale.set(s, s, s); p.s.material.rotation += p.spin * dt; p.s.material.opacity = Math.max(0, p.life) * .75; p.s.material.color.copy(white).lerp(warm, RR.warmth(t) * .4).multiplyScalar(.35 + day * .65); if (p.life <= 0) p.s.visible = false; }
  // lift
  const U = tower.userData;
  const atFloor = Math.abs(lift.y - lift.target) < .003;
  if (atFloor) {
    lift.y = lift.target; lift.wait -= dt;
    lift.doors = Math.min(1, lift.doors + dt * 1.6 * (lift.wait > .6 ? 1 : -1.2)); lift.doors = Math.max(0, lift.doors);
    if (lift.riding) { lift.riding = false; RR.sfx.motor(false); RR.sfx.chime(); setTimeout(() => RR.sfx.doors(), 350); }
    if (lift.forced && lift.target === FLOORS - 1 && !lift.dinged) { lift.dinged = true; lift.wait = 3; if (!RR.egg('lift')) RR.toast('Ding. Level ' + String(FLOORS - 1).padStart(2, '0') + '.', 1300); }
    if (lift.wait <= 0 && lift.doors <= 0) { let nf; do { nf = Math.floor(rnd() * FLOORS); } while (nf === lift.target); lift.target = lift.forced && !lift.dinged ? FLOORS - 1 : nf; lift.forced = false; lift.dinged = false; lift.wait = 2.2 + rnd() * 2.5; }
  } else {
    lift.doors = Math.max(0, lift.doors - dt * 2);
    if (lift.riding && lift.doors <= 0) RR.sfx.motor(true);
    if (lift.doors <= 0) { const diff = lift.target - lift.y, sp = Math.min(Math.abs(diff), 2.2 * dt * m + (m ? 0 : 1)); lift.y += Math.sign(diff) * Math.max(sp * Math.min(1, Math.abs(diff) * 1.4 + .25), 0); lift.dir = Math.sign(diff); }
  }
  const cy = floorY(lift.y); U.carG.position.y = cy;
  U.dl.position.x = -.5 - lift.doors * .48; U.dr.position.x = .5 + lift.doors * .48;
  U.landings.forEach((ld, k) => { const o = Math.abs(lift.y - k) < .01 ? lift.doors : 0; ld.L.position.x = -.46 - o * .44; ld.R.position.x = .46 + o * .44; });
  const top = BASEY + U.SH - .2, cTop = cy + 2.36; U.cables.forEach(c => { const len = Math.max(.1, top - cTop); c.scale.y = len; c.position.y = cTop + len / 2; });
  U.cw.position.y = BASEY + 1 + (U.SH - 4) * (1 - lift.y / FLOORS);
  // temple
  templeOn += ((night > .5 ? .55 + templeBoost * .45 : templeBoost * .25) - templeOn) * .04;
  flameM.opacity = Math.min(1, templeOn * 1.4); templeLight.intensity = templeOn * 45 * (.85 + .15 * Math.sin(el * 13));
  lamps.children.forEach((c, i) => { if (c.isSprite) c.material.opacity = templeOn * (.6 + .3 * Math.sin(el * 9 + i)); });
  temple.userData.gold.emissiveIntensity = templeOn * .9;
  temple.userData.flag.rotation.y = Math.sin(el * 3) * .25 * m;
  if (sparks.life > 0) { sparks.life -= dt; const p = sparks.pts.geometry.attributes.position; for (let i = 0; i < sparks.n; i++) { const v = sparks.vel[i]; v.y -= 6 * dt; p.setXYZ(i, p.getX(i) + v.x * dt, p.getY(i) + v.y * dt, p.getZ(i) + v.z * dt); } p.needsUpdate = true; sparks.pts.material.opacity = Math.min(1, sparks.life); }
  // lake + coracle + ripples
  waterNormal.offset.set(el * .012, el * .008);
  const ca = el * .09; coracle.position.set(LAKE.x + Math.cos(ca) * 5.5, .45 + Math.sin(el * 2) * .04, LAKE.z + Math.sin(ca) * 4); coracle.rotation.y = -ca; coracle.rotation.z = Math.sin(el * 1.6) * .05;
  for (let i = ripples.length - 1; i >= 0; i--) { const r = ripples[i]; r.t += dt; if (r.t < 0) { r.m.visible = false; continue; } r.m.visible = true; const s = 1 + r.t * 5; r.m.scale.set(s, s, s); r.m.material.opacity = Math.max(0, .7 - r.t * .45); if (r.t > 1.6) { world.remove(r.m); ripples.splice(i, 1); } }
  // clouds
  clouds.forEach(c => { const u = c.userData; u.ang += u.v * dt * m * .5; c.position.set(Math.cos(u.ang) * u.rad, u.y, Math.sin(u.ang) * u.rad); c.rotation.y = -u.ang; });
  // birds circle in daylight
  flock.visible = day > .4; const fa = el * .12; flock.position.set(Math.cos(fa) * 36, 26 + Math.sin(el * .5) * 2, Math.sin(fa) * 30); flock.rotation.y = -fa;
  birds.forEach(b => { const f = Math.sin(el * 8 + b.ph) * .7 * m; b.wl.rotation.z = f; b.wr.rotation.z = -f; });
  // shooting stars
  if (m && night > .75 && Math.random() < dt * .05) shoot(new THREE.Vector3((Math.random() - .5) * 300, 120 + Math.random() * 60, -160));
  for (let i = shoots.length - 1; i >= 0; i--) { const s = shoots[i]; s.life -= dt * .9; s.s.position.addScaledVector(s.v, dt); s.s.material.opacity = Math.max(0, s.life); if (s.life <= 0) { scene.remove(s.s); shoots.splice(i, 1); } }

  renderer.render(scene, camera);

  // HTML annotations
  if (hover && LABELS[hover.id]) {
    const a = hover.obj.localToWorld(hover.obj.userData.anchor.clone()); const [x, y, ok] = screen(a);
    let sub = LABELS[hover.id][1]; if (hover.id === 'tower') sub = `Level ${String(Math.round(lift.y)).padStart(2, '0')} ${lift.dir > 0 ? '▲' : '▼'} · click to ride`;
    annoT.textContent = LABELS[hover.id][0]; annoS.textContent = sub; anno.style.transform = `translate(${x}px, ${y}px)`; anno.hidden = !ok;
  } else anno.hidden = true;
  [[sun, sunTag, '☀ Sun'], [moon, moonTag, '☾ Moon']].forEach(([b, tag, name]) => {
    const [x, y, ok] = screen(b.position), below = b.position.y < ORB.cy - 1;
    tag.style.transform = `translate(${x}px, ${y}px)`; tag.hidden = !ok; tag.classList.toggle('dim', below);
    tag.textContent = below ? `${name} · below horizon` : `${name} · ${RR.fmt(t)}`;
  });
  hourTags.forEach((h, i) => { const [x, y, ok] = screen(orbitPos(i * Math.PI / 2)); h.style.transform = `translate(${x}px, ${y}px)`; h.hidden = !ok; });
  if (first) { first = false; document.getElementById('top').classList.add('ready'); }
}
frame();

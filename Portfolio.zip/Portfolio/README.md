# Ramakrishnan R — interactive 3D portfolio

Static site, no build step. Deploy by pushing to `main` of `ramki-ux/Portfolio` (GitHub Pages, root).

- `index.html` — page, styles, UI and sound (Web Audio, synthesized; no audio files)
- `scene.js` — the 3D Kovai valley diorama (three.js 0.160 via jsDelivr import map)
- `img/` — screenshots, portrait, `valley-poster.webp` (static fallback when WebGL is unavailable)
- `images/` — favicons, résumé, Open Graph image

Run locally with any static server (modules need http): `npx serve .` or `python3 -m http.server`.

Controls: drag the sun or moon around the orbit for a full 24 h, drag the valley to rotate, click the train / lake / tower / temple / turbines. Sound toggle in the dock or top rail, or press **M**.
